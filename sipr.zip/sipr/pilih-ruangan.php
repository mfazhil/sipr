<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="./assets/styles/style.css" />
  <title>Pengecekan | SIPR</title>
</head>

<?php
require_once __DIR__ . "/_includes/database.php";
require_once __DIR__ . "/_includes/utils.php";

session_start();

$is_user = count($_SESSION) > 0 && $_SESSION["role"] === Role::USER;
$is_admin = count($_SESSION) > 0 && $_SESSION["role"] === Role::ADMIN;


$data_ruangan = $db->query("SELECT IdRuang, NamaRuang FROM ruang");
$data = array();
$index = 1;
?>

<body>
  <?php include __DIR__ . "/_includes/navbar.php"; ?>

  <main class="main">
    <header class="main__header--no-button">
      <h1 class="main__title">Pengecekan</h1>
      <h1 class="main__title">//</h1>
      <h1 class="main__title">Pilih Ruangan</h1>
    </header>
    <table class="table">
      <thead>
        <tr>
          <th>No.</th>
          <th>Ruangan</th>
          <th class="table__action">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        while ($ruangan = $data_ruangan->fetch()) { ?>
          <tr>
            <th style="vertical-align: middle; padding: 0;"><?= $index++; ?></th>
            <td style="vertical-align: middle; padding: 0;"><?= $ruangan["NamaRuang"]; ?></td>
            <td style="display: flex; align-items: center; justify-content: center; border: none; padding: 0;">
              <a href="./pilih-tanggal.php?id=<?= $ruangan["IdRuang"]; ?>" class="button--gray small">Pilih</a>
            </td>
          </tr>
        <?php } ?>

        <?php if ($data_ruangan->rowCount() === 0) { ?>
          <tr>
            <td class="text-center" colspan="6" style="vertical-align: middle;">Tidak ada data.</td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </main>

  <?php include __DIR__ . "/_includes/footer.php"; ?>
</body>

</html>