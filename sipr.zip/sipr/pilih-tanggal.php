<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="./assets/styles/style.css" />
  <title>Pengecekan | SIPR</title>
</head>

<?php
require_once __DIR__ . "/_includes/database.php";
require_once __DIR__ . "/_includes/utils.php";

session_start();

$is_user = count($_SESSION) > 0 && $_SESSION["role"] === Role::USER;
$is_admin = count($_SESSION) > 0 && $_SESSION["role"] === Role::ADMIN;

$id_ruang = $_GET["id"];
$daftar_tanggal = $db->query("SELECT TglPengecekan FROM pengecekan LEFT JOIN pruang ON pengecekan.IdPRuang = pruang.Iddia LEFT JOIN ruang ON pruang.idruang = ruang.IdRuang WHERE ruang.IdRuang = $id_ruang GROUP BY pengecekan.TglPengecekan");

function sort_date(mixed $a, mixed $b)
{
  $date_a = strtotime($a["tanggal"]);
  $date_b = strtotime($b["tanggal"]);
  if ($date_a == $date_b) return 0;
  return ($date_a < $date_b) ? 1 : -1;
}
// usort($data, "sort_date");
$index = 1;
?>

<body>
  <?php include __DIR__ . "/_includes/navbar.php"; ?>

  <main class="main">
    <header class="main__header">
      <div>
        <h1 class="main__title">Pengecekan</h1>
        <h1 class="main__title">//</h1>
        <h1 class="main__title">Pilih Tanggal</h1>
      </div>
      <div>
        <?php if ($is_user) { ?>
          <a href="./tambah-pengecekan.php?id=<?= $id_ruang; ?>" class="button--primary small">Tambah</a>
        <?php } ?>
        <a href="./pilih-ruangan.php" class="button--gray small">Kembali</a>
      </div>
    </header>
    <table class="table">
      <thead>
        <tr>
          <th>No.</th>
          <th>Tanggal</th>
          <th class="table__action">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        while ($tanggal = $daftar_tanggal->fetch()) { ?>
          <tr>
            <th style="vertical-align: middle; padding: 0;"><?= $index++; ?></th>
            <td style="vertical-align: middle; padding: 0;"><?= $tanggal["TglPengecekan"]; ?></td>
            <td style="display: flex; align-items: center; justify-content: center; border: none; padding: 0;">
              <a href="./pengecekan.php?id=<?= $_GET["id"] ?>&date=<?= $tanggal["TglPengecekan"]; ?>" class="button--gray small">Pilih</a>
            </td>
          </tr>
        <?php } ?>

        <?php if ($daftar_tanggal->rowCount() === 0) { ?>
          <tr>
            <td class="text-center" colspan="6" style="vertical-align: middle;">Tidak ada data.</td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </main>

  <?php include __DIR__ . "/_includes/footer.php"; ?>
</body>

</html>